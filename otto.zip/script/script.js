function displayTempo(){
    var arrow = document.getElementById('animation');
    arrow.classList.toggle('rotate');
    var display = document.getElementById('tempo');
    display.classList.toggle('active');
}

function displayGarantia(){
    var arrow = document.getElementById('animati');
    arrow.classList.toggle('rotate');
    var display = document.getElementById('garantia');
    display.classList.toggle('active');
}
function displayAcesso(){
    var arrow = document.getElementById('anima');
    arrow.classList.toggle('rotate');
    var display = document.getElementById('acesso');
    display.classList.toggle('active');
    console.log (display);
}

function displayLocal(){
    var arrow = document.getElementById('ani');
    arrow.classList.toggle('rotate');
    var display = document.getElementById('local');
    display.classList.toggle('active');
}